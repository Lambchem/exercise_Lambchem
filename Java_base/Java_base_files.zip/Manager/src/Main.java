class Manager {
    //姓名name，工号id，工资salary，奖金bonus。行为：工作work()
    private String id;
    private String name;
    private double salary;
    private double bonus;
    public Manager() {
    }
    public Manager(String id, String name, double salary, double bonus) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.bonus = bonus;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    public double getBonus() {
        return bonus;
    }
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    public void work() {
        System.out.println("工号为" + id + "基本工资为" + salary + "奖金为" + bonus + "的项目经理"+name+"正在努力的做着管理工作,分配任务,检查员工提交上来的代码.....");
    }
}
class Coder {
    private String id;
    private String name;
    private double salary;
    public Coder() {
    }
    public Coder(String id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    public void work() {
        System.out.println("工号为" + id + "基本工资为" + salary + "的程序员"+name+"正在努力的写着代码......");
    }
}
public class Main {
    public static void main(String[] args) {
        Manager m = new Manager("123","张三",15000,6000);
        m.work();
        Coder c = new Coder("135","李四",10000);
        c.work();
    }
}