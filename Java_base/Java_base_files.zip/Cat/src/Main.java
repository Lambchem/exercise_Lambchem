class Cat {
    private String color;
    private String breed;
    public Cat() {
    }
    public Cat(String color, String breed) {
        this.color = color;
        this.breed = breed;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public String getBreed() {
        return breed;
    }
    public void setBreed(String breed) {
        this.breed = breed;
    }
    public void eat() {
        System.out.println(color + "色的" + breed + "正在吃鱼.....");
    }
    public void catchMouse() {
        System.out.println(color + "色的" + breed + "正在逮老鼠....");
    }
}
class Dog {
    private String color;
    private String breed;
    public Dog() {
    }
    public Dog(String color, String breed) {
        this.color = color;
        this.breed = breed;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public String getBreed() {
        return breed;
    }
    public void setBreed(String breed) {
        this.breed = breed;
    }
    public void eat() {
        System.out.println(color + "色的" + breed + "正在啃骨头.....");
    }
    public void lookHome() {
        System.out.println(color + "色的" + breed + "正在看家.....");
    }
}
public class Main {
    public static void main(String[] args) {
       Cat c = new Cat("花","波斯猫");
       c.eat();
       c.catchMouse();
       Dog d = new Dog("花","藏獒");
       d.eat();
       d.lookHome();
    }
}